# Search + Music Discord Bot

A beginner-friendly Discord bot with `/google` web search and voice music commands.

## Features

- `/google query` — returns up to five clickable web search results.
- `/play query_or_link` — searches YouTube for a song or accepts a YouTube URL.
- `/play Spotify-track-URL` — optional Spotify track-link support, when Spotify API credentials are configured; audio is played from a matching YouTube result, not streamed from Spotify.
- `/pause`, `/resume`, `/skip`, `/queue`, `/stop`, `/help`.
- Dockerfile included for hosting on a persistent container service.

## Important Spotify note

Spotify links are used only to read track metadata (title and artist) through Spotify's developer API. The bot then searches YouTube for a playable match. It does **not** extract or stream audio from Spotify. Spotify playlist/album URLs are not supported in this starter project.

## 1. Create the Discord bot

1. Open https://discord.com/developers/applications and click **New Application**.
2. Open **Bot** and create the bot if prompted. Click **Reset Token** / **View Token**, then copy it privately.
3. In **Installation** (or OAuth2 URL Generator), select the `bot` and `applications.commands` scopes.
4. Give it permissions to **View Channels**, **Send Messages**, **Embed Links**, **Connect**, and **Speak**.
5. Open the generated install URL and add it to your server.
6. Keep the token secret. Never paste it into a public repository or chat.

## 2. Run locally to test

Install Python 3.12 and FFmpeg. Then in this folder:

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

Set environment variables (do not put secrets in bot.py).

**Windows PowerShell:**
```powershell
$env:DISCORD_TOKEN="YOUR_BOT_TOKEN"
python bot.py
```

**macOS/Linux:**
```bash
export DISCORD_TOKEN="YOUR_BOT_TOKEN"
python bot.py
```

The slash commands should appear after the bot starts. Discord can take a little time to show newly synced commands.

## 3. Host it online 24/7

Use a container host that supports persistent background services (for example, Railway or another always-on Docker host). Free web-service plans often sleep and are not reliable for 24/7 voice connections.

1. Create a private GitHub repository and upload these project files.
2. Create a new service/project on your host and connect the repository.
3. Choose **Dockerfile** deployment.
4. Add these environment variables in the host dashboard:
   - `DISCORD_TOKEN` — required
   - `SPOTIFY_CLIENT_ID` — optional
   - `SPOTIFY_CLIENT_SECRET` — optional
5. Deploy and check the service logs. It should say the bot is ready.
6. Ensure your plan supports an always-running worker/container. A web-only serverless function will not work for a Discord voice bot.

## 4. Optional Spotify setup

1. Visit https://developer.spotify.com/dashboard and create an app.
2. Copy its Client ID and Client Secret.
3. Add them as `SPOTIFY_CLIENT_ID` and `SPOTIFY_CLIENT_SECRET` environment variables on your host.
4. Redeploy. Spotify track URLs can now be converted to a title/artist search and matched to YouTube audio.

## Troubleshooting

- **Slash commands don't show:** Check the bot is online, `applications.commands` was selected, and wait a few minutes. Restart and check logs for sync errors.
- **Bot joins but has no audio:** Confirm FFmpeg is installed (the Dockerfile installs it), and the bot has Connect/Speak permissions.
- **Search fails:** The search provider may temporarily rate-limit requests. Try again later.
- **YouTube playback breaks:** YouTube can change its delivery system. Update `yt-dlp` in `requirements.txt` and redeploy.
- **Bot is offline after deployment:** Check the host service is a persistent worker, not a sleeping web service, and inspect logs.
- **Token leaked:** Reset it immediately in the Discord Developer Portal and update the host's `DISCORD_TOKEN`.

## Files

- `bot.py` — bot commands and playback logic
- `requirements.txt` — Python dependencies
- `Dockerfile` — container setup including FFmpeg
- `.env.example` — environment variable template (no real secrets)
